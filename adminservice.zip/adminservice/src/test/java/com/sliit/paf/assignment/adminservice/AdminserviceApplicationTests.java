package com.sliit.paf.assignment.adminservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
