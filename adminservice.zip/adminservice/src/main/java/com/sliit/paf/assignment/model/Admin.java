package com.sliit.paf.assignment.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

@Entity
@Table(name = "admin")
public class Admin {

	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int admin_ID;
	private String admin_name;
	private String admin_password;
	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Admin(int admin_ID, String admin_name, String admin_password) {
		super();
		this.admin_ID = admin_ID;
		this.admin_name = admin_name;
		this.admin_password = admin_password;
	}
	public int getAdmin_ID() {
		return admin_ID;
	}
	public void setAdmin_ID(int admin_ID) {
		this.admin_ID = admin_ID;
	}
	public String getAdmin_name() {
		return admin_name;
	}
	public void setAdmin_name(String admin_name) {
		this.admin_name = admin_name;
	}
	public String getAdmin_password() {
		return admin_password;
	}
	//public void setAdmin_password(String admin_password) {
	//	this.admin_password = admin_password;
	//}
	public void setAdmin_password(String admin_password) {
		// TODO Auto-generated method stub
		this.admin_password = admin_password;
	}

	
	
}
