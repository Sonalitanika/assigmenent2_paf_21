package com.sliit.paf.assignment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sliit.paf.assignment.model.Admin;
import com.sliit.paf.assignment.repository.AdminRepository;

@Service
public class AdminServer {

	@Autowired
	AdminRepository adminrepository;

	public List<Admin> getAll() {
		
		return adminrepository.findAll();
	}

	public String addAdmin(Admin adm) {
		String response;
		if(adminrepository.addAdmin(adm)) response = "successfully added";
		else response = "something went wrong";
		return response;
	}

	public String updateAdmin(Admin adm) {
		String response;
		if(adminrepository.updateAdmin(adm)) response = "successfully updated";
		else response = "something went wrong";
		return response;
	}


	
}
