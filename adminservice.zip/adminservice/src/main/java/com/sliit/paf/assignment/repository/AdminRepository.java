package com.sliit.paf.assignment.repository;

import java.sql.ResultSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.sliit.paf.assignment.model.Admin;

@Repository
public class AdminRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	private final String GET_ALL = "SELECT * FROM admin";
	private final String INSER_ADMIN = "INSERT INTO admin (admin_ID,admin_name,admin_password) values (?,?,?)";
	private final String UPDATE_ADMIN = "UPDATE admin set admin_name=?, admin_password=? WHERE admin_ID=?";

	
	private RowMapper<Admin> rowMapper = (ResultSet rs, int rowNum) -> {
		Admin admin = new Admin();
		admin.setAdmin_ID(rs.getInt(1));
		admin.setAdmin_name(rs.getString(2));
		admin.setAdmin_password(rs.getString(3));
		return admin;
	};

	public List<Admin> findAll() {
		
		return jdbcTemplate.query(GET_ALL,rowMapper);
	}
	
	public boolean addAdmin(Admin a) {
		if(jdbcTemplate.update(INSER_ADMIN,a.getAdmin_ID(),a.getAdmin_name(),a.getAdmin_password())>0) return true;
		else return false;
	}

	public boolean updateAdmin(Admin a) {
		if(jdbcTemplate.update(UPDATE_ADMIN,a.getAdmin_ID(),a.getAdmin_name(),a.getAdmin_password())>0) return true;
		else return false;
	}


}
